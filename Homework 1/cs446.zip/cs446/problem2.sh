#!/bin/sh
ps -ef|more
ps -aux|more
